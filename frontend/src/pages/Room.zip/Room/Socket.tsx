import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import SockJS from 'sockjs-client';
import RoomPage from './RoomPage';
import { useLocation } from 'react-router-dom';
import Chat from './Chat';

const SocketContainer = styled.div`

`;

const ChatPage = styled.div`
  width: 400px;
  height: 650px;
  border: 2px solid red;
`
const WebcamPage = styled.div`
 width: 700px;
  height: 650px;
  border: 2px solid blue;
`

const Socket = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const roomId = searchParams.get('roomId');
  const userName = '이제윤';
  console.log(roomId)

  
  // 소캣을 관리하는 스테이트
  const [socket, setSocket] = useState<{ chatSocket: any; rtcSocket: any; }>({ chatSocket: null, rtcSocket: null });

  useEffect(() => {

    console.log('========== 소켓 연결됨 ==========')
      const chatSocket = new SockJS('https://9af7-211-193-143-25.ngrok-free.app/stomp');
      const rtcSocket = new SockJS('https://9af7-211-193-143-25.ngrok-free.app/groupcall');
      setSocket({ chatSocket, rtcSocket });
  }, []);

  return (
    <SocketContainer>
        {/* 소켓의 값이 있을 때만 컴포넌트를 렌더링 */}

        {/* {socket.rtcSocket && socket.chatSocket && (
          <RoomPage socket={socket} roomId={roomId} userName={userName}></RoomPage>        
        )} */}

        {socket.chatSocket !== null ? (
          <ChatPage>
            <Chat chatSocket={socket.chatSocket} roomId={roomId} userName={userName} />
          </ChatPage>
        ) : null}


    </SocketContainer>
  );
};

export default Socket;
